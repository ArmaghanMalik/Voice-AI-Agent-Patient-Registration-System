# # scripts/test_ai_call_flow.py
# import time
# import json
# import requests
# from sqlalchemy.orm import Session
# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker


# # from app.services.voice_agent_service import VoiceAgentService
# from app.core.config import get_settings
# from app.models.call_transcript import CallTranscript


# import os
# import sys
# import json
# import requests
# from sqlalchemy.orm import Session
# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker
# import httpx

# # Make project root importable when run as file path
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

# from app.core.config import get_settings
# from app.models.call_transcript import CallTranscript

# def start_vapi_call(phone_number: str) -> dict:
#     settings = get_settings()
#     headers = {
#         "Authorization": f"Bearer {settings.vapi_api_key}",
#         "Content-Type": "application/json",
#     }
#     payload = {
#         "assistantId": settings.vapi_assistant_id,
#         "customer": {"number": phone_number},
#     }
#     resp = httpx.post("https://api.vapi.ai/call", headers=headers, json=payload, timeout=30)
#     resp.raise_for_status()
#     return resp.json()

# # ───────────────────────────────
# # Setup DB session (replace with your DB URL)
# # ───────────────────────────────
# settings = get_settings()
# engine = create_engine(settings.database_url)
# SessionLocal = sessionmaker(bind=engine)

# # ───────────────────────────────
# # Step 1: Trigger a Vapi call
# # ───────────────────────────────
# phone_number = "+1234567890"  # test number
# # vapi_client = VapiClient()

# print("Starting AI phone call to:", phone_number)
# call_response = start_vapi_call(phone_number)
# # call_response = vapi_client.start_call(phone_number)
# print("Call initiated:", call_response)

# # Extract call ID from response (depends on Vapi API)
# call_id = call_response.get("id") or call_response.get("call_id")
# if not call_id:
#     raise RuntimeError("Call ID not returned by Vapi API")

# # ───────────────────────────────
# # Step 2: Simulate a tool-call webhook
# # ───────────────────────────────
# # This simulates Vapi calling your /voice/tool-call endpoint
# tool_call_payload = {
#     "message": {
#         "call": {"id": call_id, "customer": {"number": phone_number}},
#         "toolCallList": [
#             {
#                 "id": "tool-1",
#                 "function": {
#                     "name": "lookup_caller_by_phone",
#                     "arguments": json.dumps({"phone_number": phone_number})
#                 }
#             }
#         ]
#     }
# }

# print("Simulating tool-call webhook...")
# tool_call_url = "http://127.0.0.1:8000/voice/tool-call"
# resp = requests.post(tool_call_url, json=tool_call_payload)
# print("Tool-call response:", resp.json())

# # ───────────────────────────────
# # Step 3: Simulate end-of-call webhook
# # ───────────────────────────────
# transcript_text = "Hello! This is a test call from the AI assistant."

# end_call_payload = {
#     "message": {
#         "call": {"id": call_id, "customer": {"number": phone_number}, "endedReason": "completed", "durationSeconds": 12},
#         "artifact": {"transcript": transcript_text}
#     }
# }

# print("Simulating end-of-call webhook...")
# end_call_url = "http://127.0.0.1:8000/voice/end-of-call"
# resp = requests.post(end_call_url, json=end_call_payload)
# print("End-of-call response:", resp.json())

# # ───────────────────────────────
# # Step 4: Verify transcript saved in DB
# # ───────────────────────────────
# db: Session = SessionLocal()
# record = db.query(CallTranscript).filter_by(vapi_call_id=call_id).first()
# if record:
#     print("Transcript saved in DB:", record.transcript)
# else:
#     print("Transcript not found in DB!")

# db.close()


# app/scripts/test_ai_call_flow.py
import json
import os
import sys

import httpx
import requests
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

# Make project root importable when running as:
# python app/scripts/test_ai_call_flow.py
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.core.config import get_settings
from app.models.call_transcript import CallTranscript


def start_vapi_call(phone_number: str) -> dict:
    settings = get_settings()

    if not settings.vapi_api_key:
        raise RuntimeError("VAPI_API_KEY is missing in environment/.env")
    if not settings.vapi_assistant_id:
        raise RuntimeError("VAPI_ASSISTANT_ID is missing in environment/.env")

    headers = {
        "Authorization": f"Bearer {settings.vapi_api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "assistantId": settings.vapi_assistant_id,
        "phoneNumber": {
            "number": phone_number
        }
    }

    resp = httpx.post(
        "https://api.vapi.ai/call",
        headers=headers,
        json=payload,
        timeout=30,
    )

     # Print API response for debugging
    print("Vapi response status:", resp.status_code)
    print("Vapi response body:", resp.text)
    resp.raise_for_status()
    return resp.json()


def main() -> None:
    settings = get_settings()

    # DB session
    engine = create_engine(settings.DATABASE_URL)
    SessionLocal = sessionmaker(bind=engine)

    # Step 1: Trigger Vapi call +1 (254) 852 9868
    phone_number = "+12548529868"  # replace with a real test number
    print("Starting AI phone call to:", phone_number)

    call_response = start_vapi_call(phone_number)
    print("Call initiated:", call_response)

    call_id = call_response.get("id") or call_response.get("call_id")
    if not call_id:
        raise RuntimeError(f"Call ID not returned by Vapi API. Response={call_response}")

    # Step 2: Simulate tool-call webhook
    tool_call_payload = {
        "message": {
            "call": {"id": call_id, "customer": {"number": phone_number}},
            "toolCallList": [
                {
                    "id": "tool-1",
                    "function": {
                        "name": "lookup_caller_by_phone",
                        "arguments": json.dumps({"phone_number": phone_number}),
                    },
                }
            ],
        }
    }

    print("Simulating tool-call webhook...")
    tool_call_url = "http://127.0.0.1:8000/voice/tool-call"
    tool_resp = requests.post(tool_call_url, json=tool_call_payload, timeout=30)
    tool_resp.raise_for_status()
    print("Tool-call response:", tool_resp.json())

    # Step 3: Simulate end-of-call webhook
    transcript_text = "Hello! This is a test call from the AI assistant."
    end_call_payload = {
        "message": {
            "call": {
                "id": call_id,
                "customer": {"number": phone_number},
                "endedReason": "completed",
                "durationSeconds": 12,
            },
            "artifact": {"transcript": transcript_text},
        }
    }

    print("Simulating end-of-call webhook...")
    end_call_url = "http://127.0.0.1:8000/voice/end-of-call"
    end_resp = requests.post(end_call_url, json=end_call_payload, timeout=30)
    end_resp.raise_for_status()
    print("End-of-call response:", end_resp.json())

    # Step 4: Verify transcript saved in DB
    db: Session = SessionLocal()
    try:
        record = db.query(CallTranscript).filter_by(vapi_call_id=call_id).first()
        if record:
            print("Transcript saved in DB:", record.transcript)
        else:
            print("Transcript not found in DB!")
    finally:
        db.close()


if __name__ == "__main__":
    main()